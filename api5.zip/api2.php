<html>
<meta charset="utf-8">
<head>
<script>
location.href="http://aikan-tv.com/?url="+"<?php echo $_GET['url']; ?>"
</script>
</head>
<body>
</body>
</html>