<html>
<meta charset="utf-8">
<head>
<script>
location.href="http://api.xfsub.com/index.php?url="+"<?php echo $_GET['url']; ?>"
</script>
</head>
<body>
</body>
</html>