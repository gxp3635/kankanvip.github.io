<html>
<meta charset="utf-8">
<head>
<script>
location.href="http://api.wlzhan.com/sudu/?url="+"<?php echo $_GET['url']; ?>"
</script>
</head>
<body>
</body>
</html>