<html>
<meta charset="utf-8">
<head>
<script>
location.href="http://jiexi.071811.cc/jx2.php?url="+"<?php echo $_GET['url']; ?>"
</script>
</head>
<body>
</body>
</html>