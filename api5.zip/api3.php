<html>
<meta charset="utf-8">
<head>
<script>
location.href="http://j.zz22x.com/jx/?url="+"<?php echo $_GET['url']; ?>"
</script>
</head>
<body>
</body>
</html>