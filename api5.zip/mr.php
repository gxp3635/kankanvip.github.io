<html>
<meta charset="utf-8">
<head>
<script>
location.href="http://api.662820.com/xnflv/index.php?url="+"<?php echo $_GET['url']; ?>"
</script>
</head>
<body>
</body>
</html>